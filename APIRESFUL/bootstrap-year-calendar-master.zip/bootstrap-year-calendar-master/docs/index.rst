bootstrap-year-calendar
=======================

A fully customizable year calendar widget, for boostrap !

You can find all details on the `official website <http://www.bootstrap-year-calendar.com/>`_.